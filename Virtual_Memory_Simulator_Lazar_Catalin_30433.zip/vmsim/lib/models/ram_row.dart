class RamRow {
  String data;

  RamRow({required this.data});
}
